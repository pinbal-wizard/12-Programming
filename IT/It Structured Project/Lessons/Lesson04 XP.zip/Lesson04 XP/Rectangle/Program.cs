﻿class Program
{
    static void Main(string[] args)
    {
        do
        {
            try
            {
                Console.Write("Enter the length of the rectangle / square: ");
                double length = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter the width of the rectangle / square: ");
                double width = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Select an operation: 1. Calculate Area 2.Calculate Perimeter");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        double area = length * width;
                        Console.WriteLine("The area is: " + area);
                        break;
                    case 2:
                        double perimeter = 2 * (length + width);
                        Console.WriteLine("The perimeter is: " + perimeter);
                        break;
                    default:
                        Console.WriteLine("Invalid choice!");
                        break;
                }
            }
            catch
            {
                Console.WriteLine("Invalid Input please try again");
            }
            Console.WriteLine("Press any key to continue q to quit");
        } while (Console.ReadKey().Key != ConsoleKey.Q);
    }
}


/*
 * Literally half was the same code
 * Assuming it wanted a loop made it a loop
 *  Used a Do while for the first time in my life thanks mick 😊
 *  
 *  switch case makes adding more cases easier
 *  readability might be better 
 *  
 *  using System.Reflection.Metadata;
 */